#######################################################################
# Name: simple.py
# Purpose: Simple language based on example from pyPEG
# Author: Igor R. Dejanovic <igor DOT dejanovic AT gmail DOT com>
# Copyright: (c) 2009-2015 Igor R. Dejanovic <igor DOT dejanovic AT gmail DOT com>
# License: MIT License
#
# This example demonstrates grammar definition using python constructs.
# It is taken and adapted from pyPEG project (see http://www.fdik.org/pyPEG/).
#######################################################################

from __future__ import unicode_literals

import os
import operator as operator_imported      

from arpeggio import PTNodeVisitor, ZeroOrMore, Kwd, OneOrMore, ParserPython, \
    visit_parse_tree
from arpeggio import RegExMatch as _

# Grammar
def comment():          return [_("//.*"), _("/\*.*\*/")]
def literal():          return _(r'\d*\.\d*|\d+|".*?"')
def symbol():           return _(r"\w+")
def operator():         return _(r"\+|\-|\*|\/|\=\=")
def relational_operator(): return _(r"\<|\<\=|\>|\>\=|\=\=")
def relation_expression(): return symbol, relational_operator(), symbol
def assignment_operator(): return _(r"\=|\+\=|-\=|\*\=|\/\=")
def unary_operator(): return _(r"\+\+|\-\-")
def assignment_statement(): return symbol, assignment_operator, expression
def unary_statement(): return symbol, unary_operator
def operation():        return symbol, operator, [literal, functioncall]
def expression():       return [literal, operation, functioncall]
def expressionlist():   return expression, ZeroOrMore(",", expression)
def returnstatement():  return Kwd("return"), expression
def ifstatement():      return Kwd("if"), "(", relation_expression, ")", block, Kwd("else"), block
def statement():        return [unary_statement, assignment_statement, ifstatement, returnstatement], ";"
def block():            return "{", OneOrMore(statement), "}"
def parameterlist():    return "(", symbol, ZeroOrMore(",", symbol), ")"
def functioncall():     return symbol, "(", expressionlist, ")"
def function():         return Kwd("function"), symbol, parameterlist, block
def simpleLanguage():   return function

class LanguageVisitor(PTNodeVisitor):
    
    def assignment(self, operands):
                  
        var_name = operands[0]
        oper = operands[1]
        value = operands[2]
        if not hasattr(self, 'variables'):
            self.variables = {}
               
        if oper == '=':
            self.variables[var_name] = value
                
        else:
            var = self.variables[var_name]
            if oper == '-=':
                var -= value
            elif oper == '+=':
                var += value
            elif oper == '*=':
                var *= value
            elif oper == '/=':
                var /= value
            self.variables[var_name] = var
                
    def unary(self, operands):
        var_name = operands[0]
        oper = operands[1]
        var = self.variables[var_name]
        if oper == '++':
            self.variables[var_name] = var + 1
        else:
            self.variables[var_name] = var - 1
            
    def relational(self, operands):
         
        var_name = operands[0]
        op = operands[1]
        value = int(operands[2])
            
        operator_dict = {'<': operator_imported.lt,
                        '<=': operator_imported.le,
                        '>' : operator_imported.gt,
                        '>=':operator_imported.ge,
                        '==':operator_imported.eq}
            
        if not var_name in self.variables:
            return False
            
        var_value = self.variables[var_name]
           
        return (operator_dict[op](var_value, value)) 
        
        
    def exec_statements(self, statements):
        
        for statement in statements:
            st_type = statement[0]
            statement_children = statement[1]
            if st_type == 'assignment':
                self.assignment(statement_children)
            elif st_type == 'unary':
                self.unary(statement_children)
            elif st_type == 'if':
                condition_check = statement_children[0]
                condition = self.relational(condition_check[1])
                if condition:
                        # execute block 1
                    inner_block = statement_children[1]
                    self.exec_statements(inner_block)
                else:
                        # execute block 2
                    inner_block = statement_children[2]
                    self.exec_statements(inner_block)
    
    def visit_simpleLanguage(self, node, children):
        print('visiting simple languae')
        self.variables = {}
        statements = children[2]
        self.exec_statements(statements)
        print(self.variables)
        
    def visit_assignment_statement(self, node, children):
        
        return 'assignment', children
            
        
    def visit_unary_statement(self, node, children):
        return 'unary', children
            
            
    def visit_ifstatement(self, node, children):
        print('visiting if')
        return 'if', children 
        
        
    def visit_relation_expression(self, node, children):
        print('visiting relation expr')
        return 'relational', children
    
    def visit_block(self, node, children):
        print('visiting block')
        return children
        
    
    def visit_expression(self, node, children):
        return(children[0])
    
    def visit_statement(self, node, children):
        print('visiting statement')
        return children[0]
    
    def visit_expressionlist(self, node, children):
        print('visiting expression list')
        return children
        
    def visit_literal(self, node, shildren):
        return int(node.value)

def main(debug=False):

    # Load test program from file
    current_dir = os.path.dirname(__file__)
    test_program = open(os.path.join(current_dir, 'program.simple')).read()

    # Parser instantiation. simpleLanguage is the definition of the root rule
    # and comment is a grammar rule for comments.
    parser = ParserPython(simpleLanguage, comment, debug=debug)

    parse_tree = parser.parse(test_program)
    visit_parse_tree(parse_tree, LanguageVisitor(debug=debug))

if __name__ == "__main__":
    # In debug mode dot (graphviz) files for parser model
    # and parse tree will be created for visualization.
    # Checkout current folder for .dot files.
    main(debug=False)
