'''
Funkcije i funkcionalno programiranje 
'''

#Zadatak 1
print("--------- Zadatak 1 ----------")

radnici = {}
def languages(id_radnika, level, **lang_levels):
    lang = []
    print(level)
    for k,v in lang_levels.items():
        if  v >= level:
            lang.append(k)
    radnici[id_radnika] = lang
    

languages(1, 4, English = 5, German = 4, French = 3)
print(radnici)

#Zadatak 2
print("--------- Zadatak 2 ----------")

def longest_word(word_list):
    longest = word_list[0]
    for index, word in enumerate(word_list):
        if len(word) > len(longest):
            longest = word
            longest_index = index
            
    return (longest_index, longest)

reci = ["neke", "reci", "i" , "jos", "najduza"]
print(longest_word(reci))

#Zadatak 3
print("--------- Zadatak 3 ----------")
import datetime
def log(func):
    def func_with_logging(*args, **kwargs):
        print("Poziva se \"{0}\" u {1}".format(func.__name__, datetime.datetime.now()))
        r = func(*args, **kwargs)
        print("Zavrseno izvrsavanje \"{0}\" u {1}".format(func.__name__, datetime.datetime.now()))
        return r
    return func_with_logging
 
@log
def square(x):
    return x * x
 
print(square(3))

#Zadatak 4
print("--------- Zadatak 4 ----------")

longer_words = [w for w in reci if len(w) >  3]
print(longer_words)
squares = [n*n for n in range(1,11) if n % 2==0]
print(squares)

#Zadatak 5
print("--------- Zadatak 5 ----------")

cubes = (n**3 for n in range(1,101) if n% 2 == 1)
print(cubes.__next__())
print(cubes.__next__())
print(cubes.__next__())

#Zadatak 6
print("--------- Zadatak 6 ----------")

prod = lambda x,y: x*y
print(prod(2,3))