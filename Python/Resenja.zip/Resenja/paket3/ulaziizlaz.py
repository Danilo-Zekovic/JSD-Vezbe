'''
Created on Nov 2, 2014

@author: xxx
'''

import os, rootmodule, pickle, sys

root_dir = os.path.abspath(os.path.dirname(rootmodule.__file__))
print(root_dir)

def zadatak1():
    sys.stdout.write("Unesite ime: ")
    sys.stdout.flush()
    ime = sys.stdin.readline()
    print(ime)
    
    ime = input("Unesite ime: ")
    print(ime)
    
    
    

def zadatak2():
    try:
        root_dir = os.path.abspath(os.path.dirname(rootmodule.__file__))
        print(root_dir)
        path = os.path.join(root_dir, "resources", "test.txt")
        print(path)
        with open(path) as f:
            for line in f:
                print(line,end="")
    except FileNotFoundError as e:
        print(e )

zadatak2()

def zadatak3():
    file_path = input("Unesite naziv fajla: ")
    try:
        root_dir = os.path.abspath(os.path.dirname(rootmodule.__file__))
        path = os.path.join(root_dir, "resources", file_path)
        text = open(path).read()
        mapa = {}
        for c in text:
            c = c.lower()
            if c.isalpha():
                if c in mapa:
                    num = mapa[c]
                else:
                    num = 0
                num += 1
                mapa[c] = num
        out_path = os.path.join(root_dir, "resources", "output.txt")
        out_file = open(out_path, "w")
        for key in sorted(mapa):
            out_file.write(key +  " : " + str(mapa[key]) +"\n")
            
    except FileNotFoundError:
        print("Ne postoji fajl unetog naziva")
        

def zadatak4():
    lista = [1,2,3,4,5]
    root_dir = os.path.abspath(os.path.dirname(rootmodule.__file__))
    path = os.path.join(root_dir, "resources", "zadatak4")
    file = open(path, "wb") #b stoji za binary
    pickle.dump(lista, file, pickle.HIGHEST_PROTOCOL) #najnoviji protokol
    file.close()
    
    file = open(path, "rb")
    obj = pickle.load(file)
    file.close()
    print(obj)
    
zadatak4()
    
        
    
    
    




