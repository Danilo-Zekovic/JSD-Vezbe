'''
Created on Nov 2, 2014

@author: xxx
'''

from paket1.test import NekaTamo


klasa = NekaTamo()
print(klasa.x)

