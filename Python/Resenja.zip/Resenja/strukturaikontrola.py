'''
Struktura programa i kontrola toka
'''

#Zadatak 1
print("--------- Zadatak 1 ----------")
b = False

if b:
    def funkcija(c,d):
        return c - d
else:
    def funkcija(c,d):
        return c + d
    
    
print (funkcija(4,3))

#Zadatak 2
print("--------- Zadatak 2 ----------")

def make_ing_form(word):
    if not word.isalpha():
        return None
        
    if word.endswith("ie"):
        return word[0:-2] + "ying"
    
    last_letter = word[-1]
    if last_letter == "e":
        return word[0:-1] + "ing"

    if len(word) == 3 and consonant(word[0]) and is_vowel(word[1]) and consonant(word[2]):
        return word + word[-1] + "ing"
    
    return word + "ing"

def is_vowel(c):
    vowels = ["a", "e", "i", "o", "u"]
    return c in vowels

def consonant(c):
    return not is_vowel(c)
    

print(make_ing_form("lie"))
print(make_ing_form("move"))
print(make_ing_form("hug"))
print(make_ing_form("45"))


#Zadatak 3
print("--------- Zadatak 3 ----------")
def zbir1(list1, list2):
    ret = []
    if len(list1) != len(list2):
        return None
    for el1, el2 in zip(list1, list2):
        ret.append(el1 + el2)
    
    return ret
        

def zbir2(list1, list2):
    ret = []
    if len(list1) != len(list2):
        return None
    for i in range(0, len(list1)):
        el1 = list1[i]
        el2 = list2[i]
        ret.append(el1 + el2)
    return ret
        

list1 = [1,5,6,3,6]
list2 = [3,5,3,2,5]
print (zbir1(list1,list2))
print (zbir2(list1,list2))
