'''
Tipovi i objekti
'''


#Zadatak 1
print("--------- Zadatak 1 ----------")
principal = 1000
rate = 0.05
numyears = 5
year = 1
print (type(principal))
while year < numyears:
    principal = principal * (1 + rate)
    year += 1
    print("U godini {0} principal je: {1:0.1f}".format(year, principal))
print(type(principal))


#Zadatak 2
print("--------- Zadatak 2 ----------")
a = 1
b = 1
print(a is b)
print(a == b) #Isti objekat, isti po vrednosti
list1 = [1, 2, 3, 4]
list2 = [1, 2, 3, 4]
print(list1 is list2)
print(list1 == list2) #Nije isti objekat, ali su jednake po vrednosti

#Zadatak 3
print("--------- Zadatak 3 ----------")
from operator import add, sub, mul

funkcije = [add, sub, mul]
brojevi = [2,5,8,3]
rez = None
for i in range(0, len(funkcije)):
    if rez is None:
        rez = funkcije[i](brojevi[i], brojevi[i + 1])
    else:
        rez = funkcije[i](rez, brojevi[i + 1])
     
print(rez)


#Zadatak 4
print("--------- Zadatak 4 ----------")

#prvi nacin
def map_to_lenghts(lista):
    lenghts = []
    for word in lista:
        lenghts.append(len(word))
    return lenghts

lista = ["nesto", "tamo", "dugacko"]
duzine1 = map_to_lenghts(lista)
print(duzine1)

#drugi nacin, sa list comprehension-om
duzine2 = [len(rec) for rec in lista]
print(duzine2)

#Zadatak 5
print("--------- Zadatak 5 ----------")
def char_feq(string):
    mapa = dict()
    for c in string:
        num = 0 
        if c in mapa:
            num = mapa[c]
        num += 1
        mapa[c] = num
    return mapa

print(char_feq("aaabbbsssaavv"))

#Zadatak 6
print("--------- Zadatak 6 ----------")
x = 6
 
mapa = {10:"deset",
         9: "devet",
         8: "osam",
         7: "sedam",
         6: "sest"}
string = mapa.get(x, "nije polozeno")
print(string)

