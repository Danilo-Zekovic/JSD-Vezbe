class NekaTamo(object):
    
    def __init__(self):
        self.__x = 5
        
    @property
    def x(self):
        return self.__x
    
    @x.setter
    def x(self,x):
        self.__x = x
        

test = NekaTamo()
print(test.x)
test.x = 10
print(test.x)